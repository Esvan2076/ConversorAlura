import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Scanner;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

class ExchangeRateAPI {
    private static final String API_KEY = "9c9093084855e96f6e23c367";
    private static final String BASE_URL = "https://v6.exchangerate-api.com/v6/";

    public static JsonObject obtenerTasas(String monedaBase) throws Exception {
        String urlString = BASE_URL + API_KEY + "/latest/" + monedaBase;
        URL url = new URL(urlString);
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("GET");

        BufferedReader in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        String inputLine;
        StringBuffer contenido = new StringBuffer();
        while ((inputLine = in.readLine()) != null) {
            contenido.append(inputLine);
        }

        in.close();
        conn.disconnect();

        Gson gson = new Gson();
        return gson.fromJson(contenido.toString(), JsonObject.class);
    }
}

class ConversorMoneda {
    private JsonObject tasas;

    public ConversorMoneda(String monedaBase) throws Exception {
        this.tasas = ExchangeRateAPI.obtenerTasas(monedaBase);
    }

    public double convertir(String desdeMoneda, String aMoneda, double cantidad) {
        double tasaDesde = tasas.getAsJsonObject("conversion_rates").get(desdeMoneda).getAsDouble();
        double tasaA = tasas.getAsJsonObject("conversion_rates").get(aMoneda).getAsDouble();
        return cantidad * (tasaA / tasaDesde);
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            // Preguntar al usuario la moneda de origen
            System.out.print("Ingrese la moneda de origen (por ejemplo, USD): ");
            String desdeMoneda = scanner.nextLine().toUpperCase();

            // Preguntar al usuario la cantidad a convertir
            System.out.print("Ingrese la cantidad a convertir: ");
            double cantidad = Double.parseDouble(scanner.nextLine());

            // Preguntar al usuario la moneda de destino
            System.out.print("Ingrese la moneda de destino (por ejemplo, EUR): ");
            String aMoneda = scanner.nextLine().toUpperCase();

            // Crear el convertidor de monedas y realizar la conversión
            ConversorMoneda conversor = new ConversorMoneda(desdeMoneda);
            double cantidadConvertida = conversor.convertir(desdeMoneda, aMoneda, cantidad);
            System.out.println(cantidad + " " + desdeMoneda + " = " + cantidadConvertida + " " + aMoneda);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            scanner.close();
        }
    }
}
